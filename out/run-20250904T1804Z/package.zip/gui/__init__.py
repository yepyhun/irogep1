# GUI csomag inicializálás (exportok opcionális)
