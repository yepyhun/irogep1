from __future__ import annotations
from pathlib import Path
from typing import Iterable, List, Tuple

# Projekt gyökér: gui/ mappa szomszédja
BASE_DIR = Path(__file__).resolve().parents[1]

PRPS_DIR = BASE_DIR / "PRPs"
EXAMPLES_DIR = BASE_DIR / "EXAMPLES"
GUIDES_DIR = BASE_DIR / "GUIDES"

ALLOWED_DIRS = {
    "PRPs": PRPS_DIR,
    "EXAMPLES": EXAMPLES_DIR,
    "GUIDES": GUIDES_DIR,
}

ALLOWED_EXTS = {".md", ".txt"}
MAX_BYTES = 128 * 1024

def _iter_files_onelevel(root: Path):
    if not root.exists():
        return []
    items = []
    for p in sorted(root.iterdir()):
        if p.is_file() and not p.name.startswith("."):
            if p.suffix.lower() in ALLOWED_EXTS and p.stat().st_size <= MAX_BYTES:
                items.append(p)
    return items

def list_cookbook_entries(limit: int = 200) -> list[tuple[str, Path]]:
    # Nem rekurzív listázás a PRPs/ EXAMPLES/ GUIDES/ gyökerekben.
    items: List[Tuple[str, Path]] = []
    for root in (PRPS_DIR, EXAMPLES_DIR, GUIDES_DIR):
        for f in _iter_files_onelevel(root):
            rel = str(f.relative_to(BASE_DIR).as_posix())
            items.append((rel, f))
            if len(items) >= limit:
                return items
    return items

def read_snippet(path: Path, max_chars: int = 4000) -> str:
    try:
        txt = path.read_text(encoding="utf-8", errors="ignore")
        return txt[:max_chars]
    except Exception:
        return ""

def save_snippet(target_dir: str, filename: str, content: str) -> str:
    # Biztonságos mentés az egyik gyökérbe.
    # - target_dir: 'PRPs' | 'EXAMPLES' | 'GUIDES'
    # - filename: csak basename, engedélyezett kiterjesztés: .md/.txt
    # Visszatér: az új fájl relatív útvonala (projektgyökérhez képest).
    if target_dir not in ALLOWED_DIRS:
        raise ValueError("invalid target_dir")
    name = Path(filename).name
    # abszolút tiltása, '..' tiltása, path szeparátorok tiltása (Windows + POSIX)
    if Path(filename).is_absolute() or name != filename or (".." in filename) or ("/" in filename or "\\" in filename):
        raise ValueError("invalid filename")
    if Path(filename).suffix.lower() not in ALLOWED_EXTS:
        raise ValueError("invalid extension")
    root = ALLOWED_DIRS[target_dir]
    root.mkdir(parents=True, exist_ok=True)
    dst = root / name
    dst.write_text(content, encoding="utf-8")
    return str(dst.relative_to(BASE_DIR).as_posix())
