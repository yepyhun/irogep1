Rövid, célzott útmutatók helye.
