# PRP Template (váz)
Kötelező mezők: Goals, Non-Goals, Acceptance, Risks & Mitigations, Test Plan, Interfaces (I/O).
