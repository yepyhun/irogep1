Golden példák – jó minták.
