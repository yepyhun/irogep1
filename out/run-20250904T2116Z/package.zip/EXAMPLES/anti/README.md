Anti példák – kerülendő minták.
