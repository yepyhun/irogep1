ni .\PRPs\hello.md -Force -Value "# Hello PRP`nEz egy próba."
