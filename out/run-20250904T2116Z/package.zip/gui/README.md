GUI projekt váz (Windows). Későbbi lépésben kap magyar, „nagymama-barát” kezelőfelületet.
